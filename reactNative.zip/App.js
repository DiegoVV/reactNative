import React, {Fragment} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  Button,
} from 'react-native';

const App = () => {
  var select
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Rock, Paper, Scissors</Text>
      <Button>
        onPress={select=0}
        title="Rock"
        color="#505050"
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  scroll: {
    flex: 1,
    backgroundColor: "#333"
  },
  container: {
    flex: 1,
    justifyContent: "flex-start",
    alignItems: "center",
    backgroundColor: "#333"
  },
  title: {
    fontSize: 30,
    textAlign: "center",
    margin: 20,
    color: "#FFF"
  },
});

export default App;
